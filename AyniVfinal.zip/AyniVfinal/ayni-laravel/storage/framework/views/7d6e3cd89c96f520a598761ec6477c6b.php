<?php $__env->startSection('titulo', 'Usuarios'); ?>

<?php $__env->startSection('contenido'); ?>
<main class="container py-4 py-lg-5">
  <h1 class="display-title fw-bold mb-3">Administración</h1>
  <?php echo $__env->make('admin._tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="d-flex gap-2 mb-3">
    <a href="<?php echo e(route('admin.usuarios')); ?>" class="btn btn-outline-secondary btn-sm">Todos</a>
    <a href="<?php echo e(route('admin.usuarios', ['estado' => 'pendientes'])); ?>" class="btn btn-outline-secondary btn-sm">Pendientes de verificar</a>
  </div>

  <div class="card-ayni p-3 table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th>Nombre</th><th>Rol</th><th>DNI</th><th>Distrito</th><th>Verificado</th><th>Cuenta</th><th></th></tr></thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td>
              <div class="d-flex align-items-center gap-2">
                <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['user' => $u,'size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($u),'size' => 'sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                <div>
                  <?php if($u->rol === 'trabajador'): ?>
                    <a href="<?php echo e(route('trabajadores.show', $u)); ?>"><?php echo e($u->nombre_completo); ?></a>
                  <?php else: ?>
                    <?php echo e($u->nombre_completo); ?>

                  <?php endif; ?>
                  <div class="small text-secondary"><?php echo e($u->email); ?></div>
                </div>
              </div>
            </td>
            <td><?php echo e(ucfirst($u->rol)); ?><?php echo e($u->perfilTrabajador?->oficio ? ' · ' . $u->perfilTrabajador->oficio->nombre : ''); ?></td>
            <td><?php echo e($u->dni ?? '—'); ?></td>
            <td><?php echo e($u->distrito?->nombre); ?></td>
            <td>
              <span class="badge <?php echo e($u->verificado ? 'text-bg-success' : 'text-bg-warning'); ?>">
                <?php echo e($u->verificado ? 'Sí' : 'Pendiente'); ?>

              </span>
            </td>
            <td><span class="badge <?php echo e($u->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>"><?php echo e($u->activo ? 'Activa' : 'Desactivada'); ?></span></td>
            <td class="text-end text-nowrap">
              <form action="<?php echo e(route('admin.usuarios.verificar', $u)); ?>" method="post" class="d-inline">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button class="btn btn-outline-secondary btn-sm" type="submit"><?php echo e($u->verificado ? 'Quitar verificación' : 'Verificar'); ?></button>
              </form>
              <?php if($u->id !== auth()->id()): ?>
                <form action="<?php echo e(route('admin.usuarios.activar', $u)); ?>" method="post" class="d-inline"
                      data-confirmar="¿Cambiar el estado de esta cuenta?">
                  <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                  <button class="btn btn-outline-danger btn-sm" type="submit"><?php echo e($u->activo ? 'Desactivar' : 'Activar'); ?></button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" class="text-secondary">No hay usuarios con ese filtro.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="mt-3"><?php echo e($usuarios->links()); ?></div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/admin/usuarios.blade.php ENDPATH**/ ?>