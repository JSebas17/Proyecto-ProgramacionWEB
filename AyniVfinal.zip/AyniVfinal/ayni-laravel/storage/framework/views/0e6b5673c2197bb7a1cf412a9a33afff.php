<?php $__env->startSection('titulo', 'Administración'); ?>

<?php $__env->startSection('contenido'); ?>
<?php
  // Datos (vienen cacheados desde PanelController; los "?? []" evitan errores con un caché viejo)
  $estrellas = collect($metricas['distribucion'] ?? [])->mapWithKeys(fn ($n, $e) => [$e . ' ★' => $n])->all();
  $porOficio = $metricas['por_oficio'] ?? [];
  $porMes    = $metricas['por_mes'] ?? ['etiquetas' => [], 'calificaciones' => [], 'registros' => []];
  $ranking   = $metricas['ranking'] ?? [];
  $pctVerif  = $metricas['trabajadores'] > 0 ? round($metricas['verificados'] / $metricas['trabajadores'] * 100) : 0;

  $jsonVerif = json_encode([
      'titulo' => 'Verificación de trabajadores', 'centro' => 'Trabajadores',
      'etiquetas' => ['Verificados', 'Pendientes'],
      'valores' => [$metricas['verificados'], $metricas['pendientes']],
      'colores' => ['#E4BC40', '#C1121F'],
  ], JSON_UNESCAPED_UNICODE);
  $jsonEstrellas = json_encode([
      'titulo' => 'Calificaciones por estrella', 'vacio' => 'Aún no hay calificaciones.',
      'etiquetas' => array_keys($estrellas), 'valores' => array_values($estrellas),
      'colores' => ['#E4BC40', '#F2D77E', '#A8A39A', '#C1121F', '#8E1B1B'],
  ], JSON_UNESCAPED_UNICODE);
  $jsonOficios = json_encode([
      'titulo' => 'Trabajadores por oficio', 'vacio' => 'Aún no hay oficios con trabajadores.',
      'etiquetas' => array_keys($porOficio), 'valores' => array_values($porOficio),
      'colores' => ['#E4BC40', '#C1121F', '#A8A39A', '#F3F0E7', '#F2D77E', '#8E1B1B'],
  ], JSON_UNESCAPED_UNICODE);
  $jsonLinea = json_encode([
      'titulo' => 'Actividad de los últimos 6 meses', 'vacio' => 'Aún no hay actividad reciente.',
      'etiquetas' => $porMes['etiquetas'],
      'series' => [
          ['nombre' => 'Calificaciones', 'valores' => $porMes['calificaciones'], 'color' => '#E4BC40'],
          ['nombre' => 'Registros nuevos', 'valores' => $porMes['registros'], 'color' => '#F0646C'],
      ],
  ], JSON_UNESCAPED_UNICODE);
  $jsonMedidor = json_encode([
      'titulo' => 'Promedio general', 'valor' => $metricas['promedio'], 'max' => 5, 'texto' => 'de 5 estrellas', 'color' => '#E4BC40',
  ], JSON_UNESCAPED_UNICODE);
?>
<main class="container py-4 py-lg-5">
  <h1 class="display-title mb-3">Administración</h1>
  <?php echo $__env->make('admin._tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="dash">
    
    <div class="dash-barra">
      <h2>
        <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M9 0h6v3h3v3h3v3h3v6h-3v3h-3v3h-3v3H9v-3H6v-3H3v-3H0V9h3V6h3V3h3zM12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 1 0 0-7z"/></svg>
        <span>Panel de impacto social<small>Red Ayni · Cusco · <?php echo e(now()->translatedFormat('j \d\e F Y')); ?></small></span>
      </h2>
      <div class="dash-botones">
        <span class="dash-vivo">Datos al día</span>
        <a class="dash-btn" href="<?php echo e(route('admin.calificaciones')); ?>">Moderar calificaciones</a>
        <a class="dash-btn" href="<?php echo e(route('admin.catalogos')); ?>">Catálogos</a>
        <?php if($metricas['pendientes'] > 0): ?>
          <a href="<?php echo e(route('admin.usuarios', ['estado' => 'pendientes'])); ?>" class="dash-btn rojo">
            Verificar <?php echo e($metricas['pendientes']); ?> trabajador(es) pendiente(s)
          </a>
        <?php endif; ?>
      </div>
    </div>

    <div class="dash-grid">
      
      <?php $__currentLoopData = [
        ['Trabajadores registrados', $metricas['trabajadores'], 'k-maiz', 'M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0zM4 21a8 8 0 0 1 16 0'],
        ['Identidades verificadas', $metricas['verificados'], 'k-alpaca', 'M12 3 4 6v6c0 4.5 3.2 7.8 8 9 4.8-1.2 8-4.5 8-9V6zM8.5 12l2.5 2.5 4.5-5'],
        ['Pendientes de verificar', $metricas['pendientes'], 'k-rojo', 'M12 7v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0'],
        ['Clientes', $metricas['clientes'], 'k-piedra', 'M3 21v-2a5 5 0 0 1 5-5h4M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM17 14v6M14 17h6'],
        ['Servicios activos', $metricas['servicios'], 'k-maiz', 'M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z'],
        ['Calificaciones', $metricas['calificaciones'], 'k-rojo', 'M12 3l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 21l1.2-6.5L2.5 9.9l6.6-.9z'],
      ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$etiqueta, $valor, $clase, $icono]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tile kpi dg-2 <?php echo e($clase); ?>">
          <svg class="kpi-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="<?php echo e($icono); ?>"/></svg>
          <div class="kpi-et"><?php echo e($etiqueta); ?></div>
          <div class="kpi-val"><?php echo e(number_format($valor)); ?></div>
          <?php if($etiqueta === 'Identidades verificadas'): ?>
            <div class="mini-barra" aria-hidden="true"><span style="width: <?php echo e($pctVerif); ?>%"></span></div>
            <div class="kpi-pie"><?php echo e($pctVerif); ?>% de los trabajadores</div>
          <?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
      <section class="tile dg-4" aria-labelledby="g-verif">
        <h3 id="g-verif">Verificación de trabajadores</h3>
        <p class="tile-sub">Identidades verificadas frente a pendientes</p>
        <div data-grafica="dona" data-datos='<?php echo e($jsonVerif); ?>'></div>
        <noscript><?php if (isset($component)) { $__componentOriginal75b41fe2a4e85c063c37b7f9d151b209 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.grafica-barras','data' => ['datos' => ['Verificados' => $metricas['verificados'], 'Pendientes' => $metricas['pendientes']],'titulo' => 'Verificación de trabajadores','etiqueta' => '6.5rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('grafica-barras'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['datos' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Verificados' => $metricas['verificados'], 'Pendientes' => $metricas['pendientes']]),'titulo' => 'Verificación de trabajadores','etiqueta' => '6.5rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209)): ?>
<?php $attributes = $__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209; ?>
<?php unset($__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal75b41fe2a4e85c063c37b7f9d151b209)): ?>
<?php $component = $__componentOriginal75b41fe2a4e85c063c37b7f9d151b209; ?>
<?php unset($__componentOriginal75b41fe2a4e85c063c37b7f9d151b209); ?>
<?php endif; ?></noscript>
      </section>

      <section class="tile dg-4" aria-labelledby="g-est">
        <h3 id="g-est">Calificaciones por estrella</h3>
        <p class="tile-sub">Cómo califican los clientes</p>
        <?php if(array_sum($estrellas) > 0): ?>
          <div data-grafica="pastel" data-datos='<?php echo e($jsonEstrellas); ?>'></div>
          <noscript><?php if (isset($component)) { $__componentOriginal75b41fe2a4e85c063c37b7f9d151b209 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.grafica-barras','data' => ['datos' => $estrellas,'titulo' => 'Calificaciones por estrella']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('grafica-barras'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['datos' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($estrellas),'titulo' => 'Calificaciones por estrella']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209)): ?>
<?php $attributes = $__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209; ?>
<?php unset($__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal75b41fe2a4e85c063c37b7f9d151b209)): ?>
<?php $component = $__componentOriginal75b41fe2a4e85c063c37b7f9d151b209; ?>
<?php unset($__componentOriginal75b41fe2a4e85c063c37b7f9d151b209); ?>
<?php endif; ?></noscript>
        <?php else: ?>
          <p class="graf-vacio">Aún no hay calificaciones.</p>
        <?php endif; ?>
      </section>

      <section class="tile dg-4" aria-labelledby="g-prom">
        <h3 id="g-prom">Promedio general</h3>
        <p class="tile-sub">Satisfacción de toda la plataforma</p>
        <div data-grafica="medidor" data-datos='<?php echo e($jsonMedidor); ?>'></div>
        <div class="mini-barra mt-3" aria-hidden="true"><span style="width: <?php echo e($metricas['promedio'] / 5 * 100); ?>%"></span></div>
        <div class="kpi-pie mt-2" style="font-size:.8rem;color:#A8A39A"><?php echo e($metricas['calificaciones']); ?> calificaciones en total</div>
      </section>

      
      <section class="tile dg-7" aria-labelledby="g-act">
        <h3 id="g-act">Actividad de los últimos 6 meses</h3>
        <p class="tile-sub">Calificaciones recibidas y registros nuevos</p>
        <div data-grafica="linea" data-datos='<?php echo e($jsonLinea); ?>'></div>
      </section>

      <section class="tile dg-5" aria-labelledby="g-ofi">
        <h3 id="g-ofi">Trabajadores por oficio</h3>
        <p class="tile-sub">Dónde está la oferta de la red</p>
        <?php if($porOficio): ?>
          <div data-grafica="barras" data-datos='<?php echo e($jsonOficios); ?>'></div>
          <noscript><?php if (isset($component)) { $__componentOriginal75b41fe2a4e85c063c37b7f9d151b209 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.grafica-barras','data' => ['datos' => $porOficio,'titulo' => 'Trabajadores por oficio','plomo' => true,'etiqueta' => '7rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('grafica-barras'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['datos' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($porOficio),'titulo' => 'Trabajadores por oficio','plomo' => true,'etiqueta' => '7rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209)): ?>
<?php $attributes = $__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209; ?>
<?php unset($__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal75b41fe2a4e85c063c37b7f9d151b209)): ?>
<?php $component = $__componentOriginal75b41fe2a4e85c063c37b7f9d151b209; ?>
<?php unset($__componentOriginal75b41fe2a4e85c063c37b7f9d151b209); ?>
<?php endif; ?></noscript>
        <?php else: ?>
          <p class="graf-vacio">Aún no hay oficios con trabajadores.</p>
        <?php endif; ?>
      </section>

      
      <section class="tile dg-12" aria-labelledby="g-rank">
        <h3 id="g-rank">Mejores trabajadores</h3>
        <p class="tile-sub">Top 5 por calificación promedio</p>
        <div class="table-responsive">
          <table class="rank">
            <thead><tr><th>#</th><th>Trabajador</th><th>Oficio</th><th>Distrito</th><th>Identidad</th><th>Calificación</th><th>Reseñas</th></tr></thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td>
                    <a class="quien text-decoration-none" href="<?php echo e(route('trabajadores.show', $f['id'])); ?>" style="color:inherit">
                      <span class="avatar avatar-c<?php echo e($f['color']); ?>"><span aria-hidden="true"><?php echo e($f['iniciales']); ?></span></span>
                      <?php echo e($f['nombre']); ?>

                    </a>
                  </td>
                  <td><?php echo e($f['oficio'] ?? '—'); ?></td>
                  <td><?php echo e($f['distrito'] ?? '—'); ?></td>
                  <td><span class="pill <?php echo e($f['verificado'] ? 'ok' : 'pend'); ?>"><?php echo e($f['verificado'] ? 'Verificado' : 'Pendiente'); ?></span></td>
                  <td>
                    <?php if($f['resenas'] > 0): ?>
                      <div class="nota-barra"><strong><?php echo e(number_format($f['nota'], 1)); ?></strong><div class="mini-barra" aria-hidden="true"><span style="width: <?php echo e($f['nota'] / 5 * 100); ?>%"></span></div></div>
                    <?php else: ?>
                      <span style="color:#A8A39A">Nuevo</span>
                    <?php endif; ?>
                  </td>
                  <td><?php echo e($f['resenas']); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr class="rank-vacio"><td colspan="7">Aún no hay trabajadores con perfil.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('js/graficas.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/admin/panel.blade.php ENDPATH**/ ?>