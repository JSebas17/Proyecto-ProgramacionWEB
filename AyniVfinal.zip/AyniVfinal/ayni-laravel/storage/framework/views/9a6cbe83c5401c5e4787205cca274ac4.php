<?php $__env->startSection('titulo', 'Buscar trabajo'); ?>

<?php $__env->startSection('contenido'); ?>
  
  <?php
    $buscando = $filtros['q'] !== '' || $filtros['distrito'] !== '' || $filtros['oficio'] !== '' || $filtros['cuatro']
                || $trabajadores->currentPage() > 1;
  ?>
  <?php if (! ($buscando)): ?>
    <?php echo $__env->make('partials.hero-inicio', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php endif; ?>

  <main class="container py-4 py-lg-5" id="buscar">
    <header class="mb-4">
      <h1 class="display-title mb-2">¿Qué trabajo necesitas en tu casa o negocio?</h1>
      <p class="text-secondary mb-0">Elige un oficio, ve quién está verificado y contáctalo directo.</p>
    </header>

    
    <form method="get" action="<?php echo e(route('home')); ?>" id="filtros">
      
      <input type="hidden" name="oficio" value="<?php echo e($filtros['oficio']); ?>">

      
      <div class="card-ayni search-box p-2 mb-4" role="search">
        <div class="row g-0 align-items-center">
          <div class="col-12 col-md-6 campo">
            <label class="visually-hidden" for="q">Oficio o nombre</label>
            <i class="bi bi-search" aria-hidden="true"></i>
            <input id="q" name="q" class="form-control" type="search"
                   placeholder="Ej. arreglar un tablero" value="<?php echo e($filtros['q']); ?>">
          </div>
          <div class="col-8 col-md-4 campo">
            <label class="visually-hidden" for="distrito">Distrito</label>
            <i class="bi bi-geo-alt-fill" aria-hidden="true"></i>
            <select id="distrito" name="distrito" class="form-select">
              <option value="">Todos los distritos</option>
              <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d->nombre); ?>" <?php if($d->nombre === $filtros['distrito']): echo 'selected'; endif; ?>><?php echo e($d->nombre); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-4 col-md-2 d-grid ps-2"><button class="btn btn-ayni py-2" type="submit">Buscar</button></div>
        </div>
      </div>

      
      <div class="row g-2 g-md-3 row-cols-2 row-cols-sm-3 row-cols-lg-6 mb-4">
        <?php $__currentLoopData = $oficios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $activa = ($o->nombre === $filtros['oficio']); ?>
          <div class="col">
            <button type="submit" name="oficio" value="<?php echo e($activa ? '' : $o->nombre); ?>"
                    class="cat-btn <?php echo e($activa ? 'active' : ''); ?>" <?php if($activa): ?> aria-pressed="true" <?php endif; ?>>
              <i class="bi bi-<?php echo e($iconos[$o->nombre] ?? 'tools'); ?>" aria-hidden="true"></i><?php echo e($o->nombre); ?>

            </button>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      
      <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
        
        <input type="hidden" name="verif" value="0">
        <label class="chip <?php echo e($filtros['verif'] ? 'active' : ''); ?>">
          <input type="checkbox" name="verif" value="1" hidden data-autoenviar <?php if($filtros['verif']): echo 'checked'; endif; ?>>
          <i class="bi bi-check2" aria-hidden="true"></i> Solo verificados
        </label>
        <label class="chip <?php echo e($filtros['cuatro'] ? 'active' : ''); ?>">
          <input type="checkbox" name="cuatro" value="1" hidden data-autoenviar <?php if($filtros['cuatro']): echo 'checked'; endif; ?>>
          <i class="bi bi-star-fill <?php echo e($filtros['cuatro'] ? '' : 'stars'); ?>" aria-hidden="true"></i> 4 o más
        </label>
        <div>
          <label class="visually-hidden" for="orden">Ordenar por</label>
          <select id="orden" name="orden" class="form-select chip-select" data-autoenviar>
            <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $texto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($clave); ?>" <?php if($filtros['orden'] === $clave): echo 'selected'; endif; ?>><?php echo e($texto); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <span class="ms-auto small text-secondary" aria-live="polite">
          <?php echo e($trabajadores->total()); ?> <?php echo e($trabajadores->total() === 1 ? 'resultado' : 'resultados'); ?>

          en <?php echo e($filtros['distrito'] ?: 'Cusco'); ?>

        </span>
      </div>
    </form>

    
    <section class="row g-3 row-cols-1 row-cols-sm-2 row-cols-xl-4" aria-label="Resultados de la búsqueda">
      <?php $__empty_1 = true; $__currentLoopData = $trabajadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $perfil = $t->perfilTrabajador;
          $nota   = $t->calificaciones_recibidas_avg_puntuacion;
        ?>
        <div class="col">
          <article class="tarjeta">
            <div class="d-flex gap-3 align-items-center">
              <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['user' => $t]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($t)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
              <div class="min-w-0">
                
                <h2><a href="<?php echo e(route('trabajadores.show', $t)); ?>" class="text-decoration-none"><?php echo e($t->nombre_completo); ?></a></h2>
                <div class="sub"><?php echo e($perfil?->oficio?->nombre); ?> · <?php echo e($t->distrito?->nombre); ?></div>
              </div>
            </div>

            <div class="mt-2 d-flex flex-wrap align-items-center gap-2">
              <?php if($t->verificado): ?>
                <span class="badge badge-verified rounded-pill">
                  <i class="bi bi-patch-check-fill" aria-hidden="true"></i> Identidad verificada
                </span>
              <?php endif; ?>
              <?php if($perfil && ! $perfil->disponible): ?>
                <span class="estado-ocupado"><i class="bi bi-clock" aria-hidden="true"></i> Ocupado ahora</span>
              <?php endif; ?>
            </div>

            <div class="d-flex justify-content-between align-items-baseline my-3">
              <?php if($t->calificaciones_recibidas_count > 0): ?>
                <span>
                  <i class="bi bi-star-fill stars" aria-hidden="true"></i> <strong><?php echo e(number_format($nota, 1)); ?></strong>
                  <small class="text-secondary">(<?php echo e($t->calificaciones_recibidas_count); ?>)</small>
                </span>
              <?php else: ?>
                <span class="text-secondary">Nuevo</span>
              <?php endif; ?>
              <span class="precio">
                <?php echo e($perfil?->tarifa_referencial ? 'desde S/ ' . number_format($perfil->tarifa_referencial, 0) : 'a convenir'); ?>

              </span>
            </div>

            <div class="d-flex gap-2 mt-auto">
              <a href="<?php echo e(route('trabajadores.show', $t)); ?>" class="btn btn-outline-secondary btn-sm flex-fill">Ver perfil</a>
              <?php if($t->whatsapp_url): ?>
                <a href="<?php echo e($t->whatsapp_url); ?>" target="_blank" rel="noopener" class="btn btn-whatsapp btn-sm flex-fill">
                  <i class="bi bi-whatsapp" aria-hidden="true"></i> WhatsApp
                </a>
              <?php endif; ?>
            </div>
          </article>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
          <div class="card-ayni p-4 text-center">
            <p class="h5 mb-1">No encontramos trabajadores con esos filtros</p>
            <p class="text-secondary">Prueba con otro distrito o quita algún filtro.</p>
            <div class="d-flex flex-wrap gap-2 justify-content-center">
              <a href="<?php echo e(route('home')); ?>" class="btn btn-ayni btn-sm">Quitar filtros</a>
              <?php if($filtros['verif']): ?>
                <a href="<?php echo e(route('home', array_filter(['q' => $filtros['q'], 'distrito' => $filtros['distrito'], 'oficio' => $filtros['oficio']]) + ['verif' => 0])); ?>"
                   class="btn btn-outline-secondary btn-sm">Incluir no verificados</a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endif; ?>
    </section>

    
    <div class="mt-4"><?php echo e($trabajadores->links()); ?></div>

    
    <?php if(! $buscando && $trabajadores->count() >= 3): ?>
      <section class="mt-5" id="destacados" data-carrusel-cards aria-label="Trabajadores destacados">
        <div class="seccion-titulo">
          <div>
            <h2>Trabajadores destacados</h2>
            <p>Los mejor valorados de la red · desliza para ver más</p>
          </div>
          <div class="car-flechas">
            <button type="button" data-prev aria-label="Anteriores"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 5-7 7 7 7"/></svg></button>
            <button type="button" data-next aria-label="Siguientes"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></button>
          </div>
        </div>
        <div class="car-track">
          <?php $__currentLoopData = $trabajadores->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $perfil = $t->perfilTrabajador; ?>
            <article class="tarjeta">
              <span class="destacado-pos" aria-hidden="true"><?php echo e($loop->iteration); ?></span>
              <div class="d-flex gap-3 align-items-center mt-2">
                <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['user' => $t]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($t)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                <div class="min-w-0">
                  <h3 class="h6 mb-0"><a href="<?php echo e(route('trabajadores.show', $t)); ?>" class="text-decoration-none"><?php echo e($t->nombre_completo); ?></a></h3>
                  <div class="sub"><?php echo e($perfil?->oficio?->nombre); ?> · <?php echo e($t->distrito?->nombre); ?></div>
                </div>
              </div>
              <div class="d-flex justify-content-between align-items-baseline my-3">
                <?php if($t->calificaciones_recibidas_count > 0): ?>
                  <span><i class="bi bi-star-fill stars" aria-hidden="true"></i> <strong><?php echo e(number_format($t->calificaciones_recibidas_avg_puntuacion, 1)); ?></strong>
                    <small class="text-secondary">(<?php echo e($t->calificaciones_recibidas_count); ?>)</small></span>
                <?php else: ?>
                  <span class="text-secondary">Nuevo</span>
                <?php endif; ?>
                <span class="precio"><?php echo e($perfil?->tarifa_referencial ? 'desde S/ ' . number_format($perfil->tarifa_referencial, 0) : 'a convenir'); ?></span>
              </div>
              <a href="<?php echo e(route('trabajadores.show', $t)); ?>" class="btn btn-ayni btn-sm mt-auto">Ver perfil</a>
            </article>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </section>
    <?php endif; ?>

    
    <section class="card-ayni p-4 mt-5" aria-label="Cómo funciona">
      <div class="row g-4">
        <div class="col-md-4 d-flex gap-3"><span class="step-num">1</span><div><strong>Busca</strong><div class="small text-secondary">Por oficio y distrito</div></div></div>
        <div class="col-md-4 d-flex gap-3"><span class="step-num">2</span><div><strong>Revisa</strong><div class="small text-secondary">Identidad verificada y reseñas</div></div></div>
        <div class="col-md-4 d-flex gap-3"><span class="step-num">3</span><div><strong>Contacta y califica</strong><div class="small text-secondary">Por WhatsApp, y ambos se califican</div></div></div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('js/inicio.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/home.blade.php ENDPATH**/ ?>