<?php $__env->startSection('titulo', 'Moderar calificaciones'); ?>

<?php $__env->startSection('contenido'); ?>
<main class="container py-4 py-lg-5">
  <h1 class="display-title mb-3">Administración</h1>
  <?php echo $__env->make('admin._tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="card-ayni p-3 table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th>Autor</th><th>Trabajador</th><th>Puntos</th><th>Comentario</th><th>Fecha</th><th></th></tr></thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $calificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($c->autor->nombre_completo); ?></td>
            <td><?php echo e($c->servicio->trabajador->nombre_completo); ?></td>
            <td class="stars"><?php echo e(str_repeat('★', $c->puntuacion)); ?></td>
            <td><?php echo e($c->comentario ?: '—'); ?></td>
            <td class="small text-secondary"><?php echo e($c->created_at->format('d/m/Y')); ?></td>
            <td class="text-end">
              <form action="<?php echo e(route('admin.calificaciones.destroy', $c)); ?>" method="post" data-confirmar="¿Eliminar esta calificación?">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-outline-danger btn-sm" type="submit">Eliminar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="text-secondary">No hay calificaciones.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="mt-3"><?php echo e($calificaciones->links()); ?></div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/admin/calificaciones.blade.php ENDPATH**/ ?>