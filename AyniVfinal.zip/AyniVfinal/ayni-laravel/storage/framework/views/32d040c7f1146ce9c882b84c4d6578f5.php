<?php $__env->startSection('titulo', $trabajador->nombre_completo); ?>

<?php $__env->startSection('contenido'); ?>
<?php
  $perfil   = $trabajador->perfilTrabajador;
  $nota     = $trabajador->calificaciones_recibidas_avg_puntuacion;
  $total    = $trabajador->calificaciones_recibidas_count;
  $tarifa   = $perfil?->tarifa_referencial ? 'S/ ' . number_format($perfil->tarifa_referencial, 0) : 'A convenir';
  $anios    = (int) ($perfil?->anios_experiencia ?? 0);
  $esMio    = auth()->id() === $trabajador->id;
  $puedeCalificar = ! $esMio && auth()->user()?->rol !== 'admin';
?>
<main class="container py-4 py-lg-5">
  <?php if (isset($component)) { $__componentOriginal060d7f172229b4184d888adbd9c685ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal060d7f172229b4184d888adbd9c685ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.migas','data' => ['items' => [['Inicio', route('home')], [$trabajador->nombre_completo]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('migas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Inicio', route('home')], [$trabajador->nombre_completo]])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal060d7f172229b4184d888adbd9c685ae)): ?>
<?php $attributes = $__attributesOriginal060d7f172229b4184d888adbd9c685ae; ?>
<?php unset($__attributesOriginal060d7f172229b4184d888adbd9c685ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060d7f172229b4184d888adbd9c685ae)): ?>
<?php $component = $__componentOriginal060d7f172229b4184d888adbd9c685ae; ?>
<?php unset($__componentOriginal060d7f172229b4184d888adbd9c685ae); ?>
<?php endif; ?>

  
  <nav class="subnav" aria-label="Secciones del perfil">
    <a href="#sobre-mi">Sobre mi trabajo</a>
    <a href="#trabajos">Trabajos</a>
    <a href="#resenas">Reseñas <?php if($total > 0): ?><span>(<?php echo e($total); ?>)</span><?php endif; ?></a>
  </nav>

  <div class="row g-4 mt-1">
    <div class="col-lg-8">
      <header class="d-flex align-items-center gap-3 gap-sm-4 mb-4">
        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['user' => $trabajador,'size' => 'lg','alt' => 'Foto de ' . $trabajador->nombre_completo]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($trabajador),'size' => 'lg','alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Foto de ' . $trabajador->nombre_completo)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
        <div>
          <h1 class="h2 mb-1"><?php echo e($trabajador->nombre_completo); ?></h1>
          <p class="text-secondary mb-2"><?php echo e($perfil?->oficio?->nombre); ?> · <?php echo e($trabajador->distrito?->nombre); ?>, Cusco</p>
          <div class="d-flex flex-wrap align-items-center gap-2">
            <?php if($trabajador->verificado): ?>
              <span class="badge badge-verified rounded-pill"><i class="bi bi-patch-check-fill" aria-hidden="true"></i> Identidad verificada</span>
            <?php endif; ?>
            <?php if($perfil): ?>
              <span class="small <?php echo e($perfil->disponible ? 'text-success' : 'text-secondary'); ?>">
                <i class="bi bi-circle-fill" style="font-size:.55rem" aria-hidden="true"></i>
                <?php echo e($perfil->disponible ? 'Disponible para nuevos trabajos' : 'Ocupado ahora'); ?>

              </span>
            <?php endif; ?>
          </div>
        </div>
      </header>

      
      <div class="card-ayni p-3 mb-4">
        <div class="resumen">
          <div>
            <?php if($total > 0): ?>
              <div class="valor"><?php echo e(number_format($nota, 1)); ?> <i class="bi bi-star-fill stars" aria-hidden="true"></i></div>
              <small class="text-secondary"><?php echo e($total); ?> <?php echo e($total === 1 ? 'reseña' : 'reseñas'); ?></small>
            <?php else: ?>
              <div class="valor">Nuevo</div><small class="text-secondary">sin reseñas aún</small>
            <?php endif; ?>
          </div>
          <div>
            <div class="valor"><?php echo e($anios > 0 ? $anios : '—'); ?></div>
            <small class="text-secondary"><?php echo e($anios === 1 ? 'año de experiencia' : 'años de experiencia'); ?></small>
          </div>
          <div><div class="valor"><?php echo e($tarifa); ?></div><small class="text-secondary">por visita</small></div>
        </div>
      </div>

      
      <?php if($total > 0): ?>
        <section class="card-ayni p-4 mb-4" aria-labelledby="titulo-distribucion">
          <h2 class="h5 mb-3" id="titulo-distribucion">Distribución de calificaciones</h2>
          <?php if (isset($component)) { $__componentOriginal75b41fe2a4e85c063c37b7f9d151b209 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.grafica-barras','data' => ['datos' => collect($distribucion)->mapWithKeys(fn ($n, $e) => [$e . ' ★' => $n])->all(),'titulo' => 'Distribución de calificaciones']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('grafica-barras'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['datos' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(collect($distribucion)->mapWithKeys(fn ($n, $e) => [$e . ' ★' => $n])->all()),'titulo' => 'Distribución de calificaciones']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209)): ?>
<?php $attributes = $__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209; ?>
<?php unset($__attributesOriginal75b41fe2a4e85c063c37b7f9d151b209); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal75b41fe2a4e85c063c37b7f9d151b209)): ?>
<?php $component = $__componentOriginal75b41fe2a4e85c063c37b7f9d151b209; ?>
<?php unset($__componentOriginal75b41fe2a4e85c063c37b7f9d151b209); ?>
<?php endif; ?>
        </section>
      <?php endif; ?>

      <section class="card-ayni p-4 mb-4" id="sobre-mi">
        <h2 class="h5">Sobre mi trabajo</h2>
        <?php if($perfil?->descripcion): ?>
          
          <p class="mb-0"><?php echo nl2br(e($perfil->descripcion)); ?></p>
        <?php else: ?>
          <p class="text-secondary mb-0">
            <?php if($esMio): ?>
              Aún no escribes nada aquí. <a href="<?php echo e(route('perfil.edit')); ?>">Cuenta qué trabajos haces</a> para que más clientes confíen en ti.
            <?php else: ?>
              Este trabajador todavía no agregó una descripción.
            <?php endif; ?>
          </p>
        <?php endif; ?>
      </section>

      <section class="card-ayni p-4 mb-4" id="trabajos">
        <h2 class="h5 mb-3">Trabajos recientes</h2>
        <div class="galeria row g-2 row-cols-2 row-cols-md-4">
          <?php $__empty_1 = true; $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col">
              <a href="<?php echo e(asset('storage/' . $f)); ?>" target="_blank" rel="noopener">
                <img src="<?php echo e(asset('storage/' . $f)); ?>" alt="Trabajo de <?php echo e($trabajador->name); ?>" loading="lazy">
              </a>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php for($i = 0; $i < 4; $i++): ?>
              <div class="col"><div class="photo-slot"><i class="bi bi-image" aria-hidden="true"></i></div></div>
            <?php endfor; ?>
          <?php endif; ?>
        </div>
        <?php if($fotos->isEmpty()): ?>
          <p class="small text-secondary mt-3 mb-0">
            <?php if($esMio): ?>
              Todavía no subiste fotos. <a href="<?php echo e(route('servicios.index')); ?>">Agrégalas en tus servicios</a>.
            <?php else: ?>
              Todavía no hay trabajos publicados.
            <?php endif; ?>
          </p>
        <?php endif; ?>
      </section>

      <section class="card-ayni p-4" id="resenas" aria-labelledby="titulo-resenas">
        <h2 class="h5 mb-3" id="titulo-resenas">Reseñas</h2>
        <?php $__empty_1 = true; $__currentLoopData = $resenas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <article class="d-flex gap-3 <?php echo e($loop->last ? '' : 'pb-3 mb-3 border-bottom'); ?>">
            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['user' => $r->autor,'size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($r->autor),'size' => 'sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
            <div>
              <div>
                <span class="stars" aria-label="<?php echo e($r->puntuacion); ?> de 5 estrellas"><?php echo e(str_repeat('★', $r->puntuacion) . str_repeat('☆', 5 - $r->puntuacion)); ?></span>
                <strong><?php echo e($r->autor->name); ?></strong>
                <span class="text-secondary small">· <?php echo e($r->autor->distrito?->nombre); ?></span>
              </div>
              <?php if($r->etiquetas): ?>
                <div class="small text-secondary"><?php echo e(implode(' · ', $r->etiquetas)); ?></div>
              <?php endif; ?>
              <?php if($r->comentario): ?><p class="mb-0"><?php echo e($r->comentario); ?></p><?php endif; ?>
            </div>
          </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p class="text-secondary mb-0">Todavía no tiene reseñas.</p>
        <?php endif; ?>
        <?php if($total > $resenas->count()): ?>
          <p class="small text-secondary mt-3 mb-0">Mostrando las <?php echo e($resenas->count()); ?> reseñas más recientes de <?php echo e($total); ?>.</p>
        <?php endif; ?>
      </section>
    </div>

    <aside class="col-lg-4">
      <div class="card-ayni p-4 sticky-side">
        <div class="h3 mb-0"><?php echo e($tarifa); ?> <small class="fs-6 fw-normal text-secondary">por visita</small></div>
        <p class="text-secondary mt-2">Tarifa publicada por el trabajador.</p>

        <?php if($esMio): ?>
          
          <p class="note">Así te ven los clientes. Una foto clara y una buena descripción generan más confianza.</p>
          <a class="btn btn-ayni w-100 mb-2" href="<?php echo e(route('perfil.edit')); ?>"><i class="bi bi-camera" aria-hidden="true"></i> Editar mi perfil y foto</a>
          <a class="btn btn-outline-secondary w-100" href="<?php echo e(route('servicios.index')); ?>">Mis servicios</a>
        <?php else: ?>
          <?php if($trabajador->whatsapp_url): ?>
            <a class="btn btn-whatsapp w-100 py-2" target="_blank" rel="noopener"
               href="<?php echo e($trabajador->whatsapp_url); ?>">
              <i class="bi bi-whatsapp" aria-hidden="true"></i> Contactar por WhatsApp
            </a>
          <?php else: ?>
            
            <button type="button" class="btn btn-outline-secondary w-100 py-2" disabled>
              <i class="bi bi-whatsapp" aria-hidden="true"></i> Sin WhatsApp disponible
            </button>
          <?php endif; ?>
          <?php if($puedeCalificar): ?>
            
            <a class="btn btn-outline-secondary w-100 mt-2" href="<?php echo e(route('calificaciones.create', $trabajador)); ?>">
              <i class="bi bi-star" aria-hidden="true"></i> Calificar un trabajo
            </a>
            <?php if(auth()->guard()->guest()): ?>
              <p class="small text-secondary mt-2 mb-0 text-center">Te pediremos ingresar para calificar.</p>
            <?php endif; ?>
          <?php endif; ?>
          <p class="note mt-3 mb-0">Antes de contratar, revisa su identidad verificada y sus reseñas.</p>
        <?php endif; ?>
      </div>
    </aside>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/trabajadores/show.blade.php ENDPATH**/ ?>