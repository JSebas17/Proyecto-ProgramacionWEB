<?php $__env->startSection('titulo', 'Ingresar'); ?>

<?php $__env->startSection('contenido'); ?>
  <main class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-5">
        <h1 class="h2 mb-2">Ingresar</h1>
        
        <p class="text-secondary">
          <?php echo e(session('url.intended') ? 'Ingresa para continuar donde estabas.' : 'Entra con tu correo para contactar o publicar.'); ?>

        </p>

        <form method="post" action="<?php echo e(route('login.post')); ?>" class="card-ayni p-4" novalidate data-bloquear>
          
          <?php echo csrf_field(); ?>

          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <div class="mb-3">
            <label class="form-label fw-semibold" for="email">Correo</label>
            
            <input id="email" name="email" class="form-control" type="email" autocomplete="email"
                   placeholder="tucorreo@ejemplo.com" value="<?php echo e(old('email')); ?>" required autofocus>
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold" for="clave">Contraseña</label>
            <input id="clave" name="clave" class="form-control <?php $__errorArgs = ['clave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password"
                   autocomplete="current-password" required>
            <?php $__errorArgs = ['clave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="recordar" id="recordar" value="1">
            <label class="form-check-label" for="recordar">Mantener mi sesión iniciada</label>
          </div>
          <button class="btn btn-ayni w-100 py-2" type="submit">Ingresar</button>
        </form>

        <p class="text-center mt-3 mb-0">¿No tienes cuenta? <a href="<?php echo e(route('registro')); ?>">Regístrate</a></p>
      </div>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>