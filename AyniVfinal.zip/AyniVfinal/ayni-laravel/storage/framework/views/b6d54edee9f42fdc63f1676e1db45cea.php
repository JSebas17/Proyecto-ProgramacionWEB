<?php $__env->startSection('titulo', 'Mi perfil'); ?>

<?php $__env->startSection('contenido'); ?>
<?php
  $perfilT = $usuario->perfilTrabajador;
  $perfilC = $usuario->perfilCliente;
  $esTrabajador = $usuario->rol === 'trabajador';
  $esCliente    = $usuario->rol === 'cliente';
?>
<main class="container py-4 py-lg-5">
  <?php if (isset($component)) { $__componentOriginal060d7f172229b4184d888adbd9c685ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal060d7f172229b4184d888adbd9c685ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.migas','data' => ['items' => [['Inicio', route('home')], ['Mi perfil']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('migas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Inicio', route('home')], ['Mi perfil']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal060d7f172229b4184d888adbd9c685ae)): ?>
<?php $attributes = $__attributesOriginal060d7f172229b4184d888adbd9c685ae; ?>
<?php unset($__attributesOriginal060d7f172229b4184d888adbd9c685ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060d7f172229b4184d888adbd9c685ae)): ?>
<?php $component = $__componentOriginal060d7f172229b4184d888adbd9c685ae; ?>
<?php unset($__componentOriginal060d7f172229b4184d888adbd9c685ae); ?>
<?php endif; ?>
  <div class="row g-4">
    <div class="col-lg-7">
      <h1 class="display-title mb-2">Mi perfil</h1>
      <p class="text-secondary">
        <?php if($esTrabajador): ?> Un perfil completo y con foto recibe más contactos.
        <?php elseif($esCliente): ?> Tu foto y tus datos ayudan a que los trabajadores confíen en ti.
        <?php else: ?> Datos de tu cuenta de administración. <?php endif; ?>
      </p>

      <form method="post" action="<?php echo e(route('perfil.update')); ?>" enctype="multipart/form-data" id="form-perfil"
            class="card-ayni p-4" novalidate data-bloquear>
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        
        <div class="foto-picker mb-4" data-foto>
          <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['user' => $usuario,'size' => 'xl','dataFotoVista' => true,'dataIniciales' => $usuario->iniciales]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($usuario),'size' => 'xl','data-foto-vista' => true,'data-iniciales' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($usuario->iniciales)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
          <div class="acciones">
            <label class="btn btn-outline-secondary btn-sm" for="foto"><i class="bi bi-camera" aria-hidden="true"></i> <?php echo e($usuario->foto ? 'Cambiar foto' : 'Subir foto'); ?></label>
            <input id="foto" name="foto" type="file" class="visually-hidden" accept="image/jpeg,image/png,image/webp" data-foto-input>
            <?php if($usuario->foto): ?>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="quitar_foto" id="quitar_foto" value="1" data-foto-quitar>
                <label class="form-check-label small" for="quitar_foto">Quitar mi foto actual</label>
              </div>
            <?php endif; ?>
            <small class="text-secondary">JPG, PNG o WEBP, máx. 3 MB. Se recorta en cuadrado y se comprime sola.</small>
            <div class="text-danger small" data-foto-aviso role="alert" hidden></div>
            <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3">
          <div class="col-sm-6">
            <label class="form-label fw-semibold" for="nombre">Nombre</label>
            <input id="nombre" name="nombre" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nombre', $usuario->name)); ?>">
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-sm-6">
            <label class="form-label fw-semibold" for="apellidos">Apellidos</label>
            <input id="apellidos" name="apellidos" class="form-control <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('apellidos', $usuario->apellidos)); ?>">
            <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-sm-6">
            <label class="form-label fw-semibold" for="telefono">Teléfono (WhatsApp)</label>
            <input id="telefono" name="telefono" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   inputmode="numeric" maxlength="11" placeholder="9XXXXXXXX" value="<?php echo e(old('telefono', $usuario->telefono)); ?>">
            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-sm-6">
            <label class="form-label fw-semibold" for="distrito_id">Distrito</label>
            <select id="distrito_id" name="distrito_id" class="form-select <?php $__errorArgs = ['distrito_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d->id); ?>" <?php if(old('distrito_id', $usuario->distrito_id) == $d->id): echo 'selected'; endif; ?>><?php echo e($d->nombre); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['distrito_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold" for="correo">Correo</label>
            <input id="correo" class="form-control" value="<?php echo e($usuario->email); ?>" disabled>
            <div class="form-text">El correo y el DNI no se cambian aquí. Si hay un error, avisa al administrador.</div>
          </div>

          <?php if($esTrabajador): ?>
            <div class="col-12"><hr class="my-1"><h2 class="h5 mt-3 mb-0">Tu trabajo</h2></div>
            <div class="col-sm-5">
              <label class="form-label fw-semibold" for="oficio_id">Oficio</label>
              <select id="oficio_id" name="oficio_id" class="form-select <?php $__errorArgs = ['oficio_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__currentLoopData = $oficios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($o->id); ?>" <?php if(old('oficio_id', $perfilT?->oficio_id) == $o->id): echo 'selected'; endif; ?>><?php echo e($o->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['oficio_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-3">
              <label class="form-label fw-semibold" for="tarifa">Tarifa (S/)</label>
              <input id="tarifa" name="tarifa" type="number" min="1" inputmode="numeric" placeholder="A convenir"
                     class="form-control <?php $__errorArgs = ['tarifa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('tarifa', $perfilT?->tarifa_referencial ? (int) $perfilT->tarifa_referencial : '')); ?>">
              <?php $__errorArgs = ['tarifa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-4">
              <label class="form-label fw-semibold" for="anios_experiencia">Años de experiencia</label>
              <input id="anios_experiencia" name="anios_experiencia" type="number" min="0" max="60" inputmode="numeric"
                     class="form-control <?php $__errorArgs = ['anios_experiencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('anios_experiencia', $perfilT?->anios_experiencia ?? 0)); ?>">
              <?php $__errorArgs = ['anios_experiencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12">
              <label class="form-label fw-semibold" for="descripcion">Sobre mi trabajo</label>
              <textarea id="descripcion" name="descripcion" rows="4" maxlength="1000"
                        class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Qué trabajos haces, en qué zonas, qué experiencia tienes…"><?php echo e(old('descripcion', $perfilT?->descripcion)); ?></textarea>
              <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12">
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" role="switch" name="disponible" id="disponible" value="1"
                       <?php if(old('disponible', $perfilT?->disponible ?? true)): echo 'checked'; endif; ?>>
                <label class="form-check-label" for="disponible">Estoy disponible para nuevos trabajos</label>
              </div>
            </div>
          <?php endif; ?>

          <?php if($esCliente): ?>
            <div class="col-12"><hr class="my-1"><h2 class="h5 mt-3 mb-0">Cómo prefieres que te contacten</h2></div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="preferencias_contacto">Preferencia de contacto</label>
              <input id="preferencias_contacto" name="preferencias_contacto" maxlength="255" placeholder="WhatsApp, por las tardes…"
                     class="form-control <?php $__errorArgs = ['preferencias_contacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('preferencias_contacto', $perfilC?->preferencias_contacto)); ?>">
              <?php $__errorArgs = ['preferencias_contacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="direccion_frecuente">Zona o dirección frecuente</label>
              <input id="direccion_frecuente" name="direccion_frecuente" maxlength="255" placeholder="Wanchaq, cerca al mercado"
                     class="form-control <?php $__errorArgs = ['direccion_frecuente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('direccion_frecuente', $perfilC?->direccion_frecuente)); ?>">
              <?php $__errorArgs = ['direccion_frecuente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          <?php endif; ?>

          <div class="col-12 d-flex flex-wrap gap-2 mt-4">
            <button class="btn btn-ayni px-4 py-2" type="submit">Guardar cambios</button>
            <a href="<?php echo e($esTrabajador ? route('trabajadores.show', $usuario) : route('home')); ?>" class="btn btn-outline-secondary py-2">
              <?php echo e($esTrabajador ? 'Ver mi perfil público' : 'Volver al inicio'); ?>

            </a>
          </div>
        </div>
      </form>

      
      <?php if (! ($usuario->rol === 'admin')): ?>
        <details class="card-ayni p-4 mt-4" <?php if($errors->has('clave_actual')): ?> open <?php endif; ?>>
          <summary class="fw-semibold">Desactivar mi cuenta</summary>
          <p class="text-secondary mt-3 mb-3">
            <?php if($esTrabajador): ?> Tu perfil y tus servicios dejarán de mostrarse. Tus calificaciones se conservan. <?php else: ?> Tu cuenta dejará de poder ingresar. <?php endif; ?>
            Escribe tu contraseña para confirmar.
          </p>
          <form method="post" action="<?php echo e(route('perfil.destroy')); ?>" class="row g-2 align-items-start" data-confirmar="¿Seguro que quieres desactivar tu cuenta?">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <div class="col-sm-7">
              <label class="visually-hidden" for="clave_actual">Contraseña actual</label>
              <input id="clave_actual" name="clave_actual" type="password" autocomplete="current-password" placeholder="Tu contraseña"
                     class="form-control <?php $__errorArgs = ['clave_actual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <?php $__errorArgs = ['clave_actual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-5 d-grid"><button class="btn btn-outline-danger" type="submit">Desactivar cuenta</button></div>
          </form>
        </details>
      <?php endif; ?>
    </div>

    
    <aside class="col-lg-5">
      <div class="card-ayni p-4 sticky-side">
        <h2 class="h5 mb-3"><?php echo e($esTrabajador ? 'Así te ven los clientes' : 'Así se ve tu perfil'); ?></h2>
        <div class="tarjeta">
          <div class="d-flex gap-3 align-items-center">
            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['user' => $usuario,'dataPreviewAvatar' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($usuario),'data-preview-avatar' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
            <div>
              <h2 id="v-nombre"><?php echo e($usuario->nombre_completo); ?></h2>
              <div class="sub" id="v-sub"></div>
            </div>
          </div>
          <?php if($usuario->verificado): ?>
            <span class="badge badge-verified rounded-pill align-self-start mt-2"><i class="bi bi-patch-check-fill" aria-hidden="true"></i> Identidad verificada</span>
          <?php elseif($esTrabajador): ?>
            <span class="small text-secondary mt-2"><i class="bi bi-hourglass-split" aria-hidden="true"></i> Verificación pendiente del administrador</span>
          <?php endif; ?>
          <?php if($esTrabajador): ?>
            <div class="d-flex justify-content-between align-items-baseline mt-3 pt-2 border-top">
              <span class="estado-ocupado" id="v-estado" hidden><i class="bi bi-clock" aria-hidden="true"></i> Ocupado ahora</span>
              <span class="precio ms-auto" id="v-precio"></span>
            </div>
          <?php endif; ?>
        </div>
        <?php if($esTrabajador): ?>
          <a class="btn btn-outline-secondary w-100 mt-3" href="<?php echo e(route('servicios.index')); ?>"><i class="bi bi-briefcase" aria-hidden="true"></i> Mis servicios</a>
        <?php endif; ?>
      </div>
    </aside>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('js/foto.js')); ?>"></script>
  <script src="<?php echo e(asset('js/perfil.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/perfil/edit.blade.php ENDPATH**/ ?>