
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['datos', 'titulo' => '', 'plomo' => false, 'etiqueta' => '4.5rem']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['datos', 'titulo' => '', 'plomo' => false, 'etiqueta' => '4.5rem']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
  $datos = (array) $datos;
  $max = max(1, ...array_values($datos ?: [0]));
  $resumen = collect($datos)->map(fn ($v, $k) => "$k: $v")->implode(', ');
?>
<div class="grafica" role="img" aria-label="<?php echo e($titulo); ?>. <?php echo e($resumen); ?>" style="--etq: <?php echo e($etiqueta); ?>">
  <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="grafica-fila" aria-hidden="true">
      <span class="etq"><?php echo e($nombre); ?></span>
      <div class="grafica-pista"><div class="grafica-barra <?php echo e($plomo ? 'plomo' : ''); ?>" style="width: <?php echo e(round($valor / $max * 100)); ?>%"></div></div>
      <span class="grafica-valor"><?php echo e($valor); ?></span>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/components/grafica-barras.blade.php ENDPATH**/ ?>