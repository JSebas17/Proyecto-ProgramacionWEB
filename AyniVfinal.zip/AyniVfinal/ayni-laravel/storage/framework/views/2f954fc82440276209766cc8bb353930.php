
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="theme-color" content="#9A0000">
  <title><?php echo $__env->yieldContent('titulo', 'Ayni'); ?> · Ayni</title>
  <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">

  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  
  <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
  
  <link href="<?php echo e(asset('css/tema-andino.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/chatbot.css')); ?>" rel="stylesheet">
</head>
<body>
  <?php $yo = auth()->user(); ?>

  
  <a class="visually-hidden-focusable position-absolute p-2 bg-white" href="#contenido">Saltar al contenido</a>

  
  <header class="cabecera">
    <div class="container py-3 d-flex flex-wrap align-items-center justify-content-between gap-3">
      <a class="marca" href="<?php echo e(route('home')); ?>" aria-label="Ayni, ir al inicio">
        <?php if (isset($component)) { $__componentOriginalb23b78d5aba0ad299e7c55fa94941fa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb23b78d5aba0ad299e7c55fa94941fa3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chakana','data' => ['class' => 'marca-icono']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chakana'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'marca-icono']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb23b78d5aba0ad299e7c55fa94941fa3)): ?>
<?php $attributes = $__attributesOriginalb23b78d5aba0ad299e7c55fa94941fa3; ?>
<?php unset($__attributesOriginalb23b78d5aba0ad299e7c55fa94941fa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb23b78d5aba0ad299e7c55fa94941fa3)): ?>
<?php $component = $__componentOriginalb23b78d5aba0ad299e7c55fa94941fa3; ?>
<?php unset($__componentOriginalb23b78d5aba0ad299e7c55fa94941fa3); ?>
<?php endif; ?>
        <span>
          <span class="marca-nombre d-block">Ayni</span>
          <span class="marca-lema d-block">Red de Empleabilidad para Trabajadores Independientes · Cusco</span>
        </span>
      </a>
      <ul class="cifras">
        <li><strong>80%</strong><span>informalidad<br>laboral en Cusco</span></li>
        <li><strong>✓</strong><span>identidad<br>verificada</span></li>
        <li><strong>★</strong><span>calificación<br>mutua</span></li>
      </ul>
    </div>
    <div class="tejido" role="presentation"></div>
  </header>

  
  <div class="menu-barra">
    <div class="container">
      <nav class="navbar navbar-expand-lg" aria-label="Menú principal">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Abrir menú">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="menu">
          <ul class="navbar-nav me-auto">
            
            <li class="nav-item">
              <a class="nav-link <?php echo e(request()->routeIs('home', 'trabajadores.*', 'calificaciones.*') ? 'active' : ''); ?>"
                 href="<?php echo e(route('home')); ?>">Buscar trabajo</a>
            </li>
            
            <?php if(! $yo || $yo->rol === 'trabajador'): ?>
              <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('ofrecer', 'publicar', 'servicios.*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('ofrecer')); ?>">Ofrecer mi servicio</a>
              </li>
            <?php endif; ?>
            <?php if($yo?->rol === 'trabajador'): ?>
              <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('servicios.index') ? 'active' : ''); ?>" href="<?php echo e(route('servicios.index')); ?>">Mis servicios</a>
              </li>
            <?php endif; ?>
            <?php if($yo?->rol === 'admin'): ?>
              <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.panel')); ?>">Administración</a>
              </li>
            <?php endif; ?>
          </ul>

          <?php if(auth()->guard()->check()): ?>
            
            <div class="menu-cuenta dropdown">
              <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['user' => $yo,'size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($yo),'size' => 'sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                <span><?php echo e($yo->name); ?></span>
              </button>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="<?php echo e(route('perfil.edit')); ?>"><i class="bi bi-person-circle me-2"></i>Mi perfil y foto</a></li>
                <?php if($yo->rol === 'trabajador'): ?>
                  <li><a class="dropdown-item" href="<?php echo e(route('trabajadores.show', $yo)); ?>"><i class="bi bi-eye me-2"></i>Ver mi perfil público</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('servicios.index')); ?>"><i class="bi bi-briefcase me-2"></i>Mis servicios</a></li>
                <?php endif; ?>
                <?php if($yo->rol === 'admin'): ?>
                  <li><a class="dropdown-item" href="<?php echo e(route('admin.panel')); ?>"><i class="bi bi-speedometer2 me-2"></i>Administración</a></li>
                <?php endif; ?>
                <li><hr class="dropdown-divider"></li>
                <li>
                  
                  <form action="<?php echo e(route('logout')); ?>" method="post" class="m-0">
                    <?php echo csrf_field(); ?>
                    <button class="dropdown-item" type="submit"><i class="bi bi-box-arrow-right me-2"></i>Cerrar sesión</button>
                  </form>
                </li>
              </ul>
            </div>
          <?php else: ?>
            <div class="d-flex align-items-center gap-3 py-2 py-lg-0">
              <a href="<?php echo e(route('login')); ?>" class="text-decoration-none fw-semibold">Ingresar</a>
              <a href="<?php echo e(route('registro')); ?>" class="btn btn-awayo btn-sm px-3">Registrarme</a>
            </div>
          <?php endif; ?>
        </div>
      </nav>
    </div>
  </div>

  
  <?php if(session('mensaje') || session('error')): ?>
    <div class="container mt-3">
      <?php if(session('mensaje')): ?>
        <div class="alert alert-success alert-dismissible fade show mb-0" role="status">
          <i class="bi bi-check-circle-fill me-1"></i> <?php echo e(session('mensaje')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar mensaje"></button>
        </div>
      <?php endif; ?>
      <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show mb-0" role="alert">
          <i class="bi bi-exclamation-triangle-fill me-1"></i> <?php echo e(session('error')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar mensaje"></button>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  
  <div id="contenido">
    <?php echo $__env->yieldContent('contenido'); ?>
  </div>

  
  <footer class="pie">
    <div class="tejido" role="presentation"></div>
    <div class="container py-4">
      <div class="row g-4">
        <div class="col-lg-6">
          <div class="d-flex align-items-center gap-2 mb-2">
            <?php if (isset($component)) { $__componentOriginalb23b78d5aba0ad299e7c55fa94941fa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb23b78d5aba0ad299e7c55fa94941fa3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chakana','data' => ['class' => 'marca-icono','style' => 'width:32px;height:32px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chakana'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'marca-icono','style' => 'width:32px;height:32px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb23b78d5aba0ad299e7c55fa94941fa3)): ?>
<?php $attributes = $__attributesOriginalb23b78d5aba0ad299e7c55fa94941fa3; ?>
<?php unset($__attributesOriginalb23b78d5aba0ad299e7c55fa94941fa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb23b78d5aba0ad299e7c55fa94941fa3)): ?>
<?php $component = $__componentOriginalb23b78d5aba0ad299e7c55fa94941fa3; ?>
<?php unset($__componentOriginalb23b78d5aba0ad299e7c55fa94941fa3); ?>
<?php endif; ?>
            <span class="marca-nombre">Ayni</span>
          </div>
          <p class="mb-0" style="max-width: 36rem">
            Ayni es la ayuda mutua andina. Esta red conecta a electricistas, pintores, gasfiteros y otros oficios
            de Cusco con clientes que quieren contratar con confianza.
          </p>
        </div>
        <div class="col-6 col-lg-3">
          <h2>Explorar</h2>
          <ul>
            <li><a href="<?php echo e(route('home')); ?>">Buscar trabajo</a></li>
            <?php if(! $yo || $yo->rol === 'trabajador'): ?>
              <li><a href="<?php echo e(route('ofrecer')); ?>">Ofrecer mi servicio</a></li>
            <?php endif; ?>
          </ul>
        </div>
        <div class="col-6 col-lg-3">
          <h2>Mi cuenta</h2>
          <ul>
            <?php if(auth()->guard()->check()): ?>
              <li><a href="<?php echo e(route('perfil.edit')); ?>">Mi perfil y foto</a></li>
              <?php if($yo->rol === 'trabajador'): ?><li><a href="<?php echo e(route('servicios.index')); ?>">Mis servicios</a></li><?php endif; ?>
              <?php if($yo->rol === 'admin'): ?><li><a href="<?php echo e(route('admin.panel')); ?>">Administración</a></li><?php endif; ?>
            <?php else: ?>
              <li><a href="<?php echo e(route('login')); ?>">Ingresar</a></li>
              <li><a href="<?php echo e(route('registro')); ?>">Registrarme</a></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
      <div class="legal mt-4 pt-3">
        Proyecto académico · Universidad Continental · Programación Web (NRC 39577) · Cusco, 2026
      </div>
    </div>
  </footer>

  
  <a href="#contenido" class="subir" id="subir" aria-label="Volver arriba" hidden><i class="bi bi-arrow-up" aria-hidden="true"></i></a>

  
  <?php if(auth()->user()?->rol !== 'admin'): ?>
    <?php echo $__env->make('partials.chatbot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php endif; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(asset('js/app.js')); ?>"></script>
  <?php if(auth()->user()?->rol !== 'admin'): ?>
    <script src="<?php echo e(asset('js/chatbot.js')); ?>"></script>
  <?php endif; ?>
  
  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>