<?php $__env->startSection('titulo', 'Catálogos'); ?>

<?php $__env->startSection('contenido'); ?>
<main class="container py-4 py-lg-5">
  <h1 class="display-title mb-3">Administración</h1>
  <?php echo $__env->make('admin._tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="row g-4">
    
    <div class="col-lg-6">
      <div class="card-ayni p-4">
        <h2 class="h5">Oficios</h2>
        <form method="post" action="<?php echo e(route('admin.catalogos.oficios.store')); ?>" class="row g-2 mb-3">
          <?php echo csrf_field(); ?>
          <div class="col-5"><input name="nombre" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nombre" value="<?php echo e(old('nombre')); ?>"></div>
          <div class="col-5"><input name="descripcion" class="form-control" placeholder="Descripción (opcional)"></div>
          <div class="col-2 d-grid"><button class="btn btn-ayni" type="submit">+</button></div>
          <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
        <ul class="list-group">
          <?php $__currentLoopData = $oficios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <span><?php echo e($o->nombre); ?> <small class="text-secondary">(<?php echo e($o->perfiles_count); ?> trabajadores)</small></span>
              <form action="<?php echo e(route('admin.catalogos.oficios.destroy', $o)); ?>" method="post" data-confirmar="¿Eliminar este oficio?">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-outline-danger btn-sm" type="submit">Eliminar</button>
              </form>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>

    
    <div class="col-lg-6">
      <div class="card-ayni p-4">
        <h2 class="h5">Distritos</h2>
        <form method="post" action="<?php echo e(route('admin.catalogos.distritos.store')); ?>" class="row g-2 mb-3">
          <?php echo csrf_field(); ?>
          <div class="col-5"><input name="nombre" class="form-control" placeholder="Nombre"></div>
          <div class="col-5"><input name="provincia" class="form-control" placeholder="Provincia" value="Cusco"></div>
          <div class="col-2 d-grid"><button class="btn btn-ayni" type="submit">+</button></div>
        </form>
        <ul class="list-group">
          <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <span><?php echo e($d->nombre); ?> <small class="text-secondary">(<?php echo e($d->usuarios_count); ?> usuarios)</small></span>
              <form action="<?php echo e(route('admin.catalogos.distritos.destroy', $d)); ?>" method="post" data-confirmar="¿Eliminar este distrito?">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-outline-danger btn-sm" type="submit">Eliminar</button>
              </form>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/admin/catalogos.blade.php ENDPATH**/ ?>