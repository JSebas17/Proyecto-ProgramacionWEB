<?php $__env->startSection('titulo', 'Registrarme'); ?>

<?php $__env->startSection('contenido'); ?>
  <main class="container py-4 py-lg-5">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <h1 class="display-title mb-2">Crea tu cuenta</h1>
        <p class="text-secondary">Primero tus datos; luego completas tu perfil según lo que necesites.</p>

        
        <form method="post" action="<?php echo e(route('registro.post')); ?>" enctype="multipart/form-data"
              class="card-ayni p-4" novalidate data-bloquear>
          <?php echo csrf_field(); ?>

          
          <fieldset class="mb-4">
            <legend class="h6">¿Qué quieres hacer en Ayni?</legend>
            <div class="row g-2">
              <div class="col-sm-6">
                <input type="radio" class="btn-check" name="rol" id="rol-cliente" value="cliente"
                       <?php if(old('rol', $rolInicial) === 'cliente'): echo 'checked'; endif; ?>>
                <label class="btn btn-rol w-100 text-start p-3" for="rol-cliente">
                  <i class="bi bi-search" aria-hidden="true"></i> <strong>Busco trabajadores</strong><br><small class="text-secondary">Soy cliente</small>
                </label>
              </div>
              <div class="col-sm-6">
                <input type="radio" class="btn-check" name="rol" id="rol-trabajador" value="trabajador"
                       <?php if(old('rol', $rolInicial) === 'trabajador'): echo 'checked'; endif; ?>>
                <label class="btn btn-rol w-100 text-start p-3" for="rol-trabajador">
                  <i class="bi bi-tools" aria-hidden="true"></i> <strong>Ofrezco mi servicio</strong><br><small class="text-secondary">Soy trabajador</small>
                </label>
              </div>
            </div>
            <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </fieldset>

          
          <div class="foto-picker mb-4" data-foto>
            <span class="avatar avatar-lg avatar-c0" data-foto-vista data-iniciales="?">
              <span aria-hidden="true"><i class="bi bi-camera"></i></span>
            </span>
            <div class="acciones">
              <label class="btn btn-outline-secondary btn-sm" for="foto"><i class="bi bi-camera" aria-hidden="true"></i> Subir foto de perfil</label>
              <input id="foto" name="foto" type="file" class="visually-hidden" accept="image/jpeg,image/png,image/webp" data-foto-input>
              <small class="text-secondary">Opcional. Con una foto clara los clientes confían más. JPG, PNG o WEBP, máx. 3 MB.</small>
              <div class="text-danger small" data-foto-aviso role="alert" hidden></div>
              <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="row g-3">
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="nombre">Nombre</label>
              <input id="nombre" name="nombre" autocomplete="given-name" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nombre')); ?>">
              <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="apellidos">Apellidos</label>
              <input id="apellidos" name="apellidos" autocomplete="family-name" class="form-control <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('apellidos')); ?>">
              <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="dni">DNI</label>
              <input id="dni" name="dni" class="form-control <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     inputmode="numeric" maxlength="8" value="<?php echo e(old('dni')); ?>">
              <div class="form-text">Solo lo ve el administrador para verificar tu identidad.</div>
              <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="telefono">Teléfono (WhatsApp)</label>
              <input id="telefono" name="telefono" autocomplete="tel-national" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     inputmode="numeric" maxlength="9" placeholder="9XXXXXXXX" value="<?php echo e(old('telefono')); ?>">
              <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="email">Correo</label>
              <input id="email" name="email" autocomplete="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" value="<?php echo e(old('email')); ?>">
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="distrito_id">Distrito</label>
              <select id="distrito_id" name="distrito_id" class="form-select <?php $__errorArgs = ['distrito_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">Elige un distrito</option>
                <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($d->id); ?>" <?php if(old('distrito_id') == $d->id): echo 'selected'; endif; ?>><?php echo e($d->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['distrito_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="col-12" data-cv data-solo-trabajador <?php if(old('rol', $rolInicial) !== 'trabajador'): ?> hidden <?php endif; ?>>
              <label class="form-label fw-semibold" for="cv">Currículum (CV) <span class="text-secondary fw-normal">· opcional</span></label>
              <input id="cv" name="cv" type="file" accept="application/pdf,.pdf" class="form-control <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-cv-input>
              <div class="form-text">Solo PDF, máximo 5 MB.</div>
              <div class="text-danger small" data-cv-aviso role="alert" hidden></div>
              <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="clave">Contraseña</label>
              <input id="clave" name="clave" autocomplete="new-password" class="form-control <?php $__errorArgs = ['clave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password">
              <div class="form-text">Mínimo 8 caracteres.</div>
              <?php $__errorArgs = ['clave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
              <label class="form-label fw-semibold" for="clave2">Repite la contraseña</label>
              <input id="clave2" name="clave2" autocomplete="new-password" class="form-control <?php $__errorArgs = ['clave2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password">
              <?php $__errorArgs = ['clave2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12">
              <div class="form-check">
                <input class="form-check-input <?php $__errorArgs = ['acepto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="checkbox" name="acepto" id="acepto" value="1" <?php if(old('acepto')): echo 'checked'; endif; ?>>
                <label class="form-check-label" for="acepto">
                  Acepto que Ayni use mis datos solo para conectarme con clientes o trabajadores. Mi DNI no se muestra públicamente.
                </label>
                <?php $__errorArgs = ['acepto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="col-12"><button class="btn btn-ayni px-4 py-2" type="submit">Crear cuenta</button></div>
          </div>
        </form>

        <p class="text-center mt-3 mb-0">¿Ya tienes cuenta? <a href="<?php echo e(route('login')); ?>">Ingresar</a></p>
      </div>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('js/foto.js')); ?>"></script>
  <script src="<?php echo e(asset('js/cv.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/auth/registro.blade.php ENDPATH**/ ?>