
<?php
  $pestanas = ['admin.panel' => 'Resumen', 'admin.usuarios' => 'Usuarios', 'admin.calificaciones' => 'Calificaciones', 'admin.catalogos' => 'Catálogos'];
  $actual = collect($pestanas)->first(fn ($texto, $ruta) => request()->routeIs($ruta), 'Resumen');
?>
<?php if (isset($component)) { $__componentOriginal060d7f172229b4184d888adbd9c685ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal060d7f172229b4184d888adbd9c685ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.migas','data' => ['items' => [['Inicio', route('home')], ['Administración', route('admin.panel')], [$actual]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('migas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Inicio', route('home')], ['Administración', route('admin.panel')], [$actual]])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal060d7f172229b4184d888adbd9c685ae)): ?>
<?php $attributes = $__attributesOriginal060d7f172229b4184d888adbd9c685ae; ?>
<?php unset($__attributesOriginal060d7f172229b4184d888adbd9c685ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal060d7f172229b4184d888adbd9c685ae)): ?>
<?php $component = $__componentOriginal060d7f172229b4184d888adbd9c685ae; ?>
<?php unset($__componentOriginal060d7f172229b4184d888adbd9c685ae); ?>
<?php endif; ?>
<ul class="nav nav-pills mb-4 gap-1">
  <?php $__currentLoopData = $pestanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta => $texto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item">
      <a class="nav-link <?php echo e(request()->routeIs($ruta) ? 'active' : ''); ?>" href="<?php echo e(route($ruta)); ?>" <?php if(request()->routeIs($ruta)): ?> aria-current="page" <?php endif; ?>><?php echo e($texto); ?></a>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/admin/_tabs.blade.php ENDPATH**/ ?>