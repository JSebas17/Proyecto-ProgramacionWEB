
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user', 'size' => '', 'alt' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user', 'size' => '', 'alt' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
  $clases = trim('avatar avatar-c' . $user->color_avatar . ($size ? ' avatar-' . $size : ''));
?>
<span <?php echo e($attributes->merge(['class' => $clases])); ?>>
  <?php if($user->foto_url): ?>
    <img src="<?php echo e($user->foto_url); ?>" alt="<?php echo e($alt); ?>" loading="lazy" decoding="async">
  <?php else: ?>
    <span aria-hidden="true"><?php echo e($user->iniciales); ?></span>
  <?php endif; ?>
</span>
<?php /**PATH D:\xampp83\htdocs\AyniVfinal\ayni-laravel\resources\views/components/avatar.blade.php ENDPATH**/ ?>